package com.example.BookMvcCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMvcCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
