package com.example.BookMvcCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMvcCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMvcCrudApplication.class, args);
	}

}
